package DataBase; // Declaring the class under the 'DataBase' package

/* Importing necessary classes for SQL operations */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataBaseConnection {

    // Defining constants for database connection details
    private final static String databaseName = "juttajoy"; // Database name
    private final static String username = "root"; // Username for connecting to the database
    private final static String password = ""; // Password for connecting to the database
    private final static String jdbcUrl = "jdbc:mysql://localhost:3306/" + databaseName; // JDBC URL for MySQL connection

    // Method to establish a connection to the database
    public static Connection getConnection() throws ClassNotFoundException, SQLException {
        Connection con = null; // Declaring connection object
        Class.forName("com.mysql.cj.jdbc.Driver"); // Loading the MySQL JDBC driver
        con = DriverManager.getConnection(jdbcUrl, username, password); // Establishing the connection to the database using the given credentials
        
        // Checking if the connection was successful
        if (con == null) {
            System.out.println("Database Not Connected !!"); // Printing an error message if connection fails
        } else {
            System.out.println("Database Connection Successful !!"); // Printing a success message if connection is successful
        }
        
        return con; // Returning the established connection
    }

    // Main method to test the database connection
    public static void main(String[] args) {
        try {
            getConnection(); // Calling the getConnection method to establish the connection
        } catch (ClassNotFoundException | SQLException e) { // Catching any exceptions related to database connection
            e.printStackTrace(); // Printing the stack trace if an exception occurs
        }
    }
}
