package Controller; // Declaring the class as part of the 'Controller' package

/* Importing classes for handling input-output operations and exceptions */
import java.io.IOException;
import java.sql.SQLException;

/* Importing List and ArrayList classes to store collections of objects (e.g., products or users) */
import java.util.ArrayList;
import java.util.List;

/* Importing Map interface for key-value data storage (useful for managing attributes or parameters) */
import java.util.Map;

/* Importing servlet-related classes to handle HTTP requests, responses, and session management */
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/* Importing the DAO class for interacting with product-related database operations */
import DAO.ProductModelDAO;

/* Importing the model class that represents a user entity */
import Model.UserModel;


@WebServlet("/OrderHistoryServlet")
public class OrderHistoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    public OrderHistoryServlet() {
        super();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        UserModel userDetails = (UserModel) session.getAttribute("userDetails");
        
        if (userDetails == null) {
            // User not logged in on this case redirecting to login page
            response.sendRedirect(request.getContextPath() + "/Pages/Login.jsp");
            return;
        }
        
        int userId = userDetails.getUserId();
        List<Map<String, Object>> orderHistory = new ArrayList<>();
        
        try {
            ProductModelDAO productDao = new ProductModelDAO();
            // Getting all order history with no limit (passing 0)
            orderHistory = productDao.getUserOrderHistory(userId, 0);
            
            request.setAttribute("orderHistory", orderHistory);
            request.getRequestDispatcher("/Pages/OrderHistory.jsp").forward(request, response);
            
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred while retrieving order history: " + e.getMessage());
            request.getRequestDispatcher("/Pages/Error.jsp").forward(request, response);
        }
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}