package Controller; // Declaring this class as part of the 'Controller' package

/* Importing classes for handling input-output operations and exceptions */
import java.io.IOException;
import java.sql.SQLException;

/* Importing the List interface for managing collections of ProductModel objects */
import java.util.List;

/* Importing classes for servlet request handling and dispatching */
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/* Importing the DAO class responsible for interacting with product-related database operations */
import DAO.ProductModelDAO;

/* Importing the model class that defines the structure of a product */
import Model.ProductModel;


/**
 * Servlet implementation class HomeServlet
 * This servlet fetches the latest products from the database and forwards them to the Home.jsp page
 */
@WebServlet("/home")
public class HomeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    private ProductModelDAO productDAO;

    public void init() {
        productDAO = new ProductModelDAO();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Getting the latest products (limit to 4)
            List<ProductModel> newArrivals = productDAO.getNewArrivals(4);
            
            // Debug: Printing how many products were found
            System.out.println("Debug - Number of new arrivals found: " + (newArrivals != null ? newArrivals.size() : "null"));
            
            if (newArrivals != null && !newArrivals.isEmpty()) {
                // Debuging: Print details of the first product
                ProductModel firstProduct = newArrivals.get(0);
                System.out.println("Debug - First product details:");
                System.out.println("  Name: " + firstProduct.getProductName());
                System.out.println("  Price: " + firstProduct.getProductPrice());
                System.out.println("  Image path: " + firstProduct.getImage());
                System.out.println("  Product code: " + firstProduct.getProductCode());
            }
            
            // Setting the products as attributes in the request
            request.setAttribute("newArrivals", newArrivals);
            
            // Forwarding to the Home.jsp page
            RequestDispatcher dispatcher = request.getRequestDispatcher("Pages/Home.jsp");
            dispatcher.forward(request, response);
            
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            System.out.println("Debug - Exception in HomeServlet: " + e.getMessage());
            // Handling error - redirect to error page or show error message
            response.sendRedirect(request.getContextPath()+ "/Pages/Error.jsp");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}