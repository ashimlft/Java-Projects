package Controller; // Declaring the class as part of the 'Controller' package

/* Importing classes for handling input-output exceptions during servlet execution */
import java.io.IOException;

/* Importing servlet-related classes for managing HTTP requests, responses, and exceptions */
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/* Importing HttpSession to manage session data across multiple requests */
import javax.servlet.http.HttpSession;

/* Importing the DAO class responsible for product-related database operations */
import DAO.ProductModelDAO;

/* Importing the model class that represents the order entity */
import Model.OrderModel;

@WebServlet("/ProcessPayment")
public class ProcessPaymentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ProcessPaymentServlet() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			HttpSession session = request.getSession();
			Integer userId = (Integer) session.getAttribute("userId");

			// Checking if user is logged in
			if (userId == null) {
				response.sendRedirect(request.getContextPath() + "/Login");
				return;
			}

			// Getting form data
			String paymentType = request.getParameter("paymentType");
			String productCode = request.getParameter("productCode");
			int quantity = Integer.parseInt(request.getParameter("quantity"));
			String size = request.getParameter("size");
			String name = request.getParameter("name");
			String address = request.getParameter("address");
			String phoneNumber = request.getParameter("phoneNumber");
			String email = request.getParameter("email");
			String category = request.getParameter("category");
			String brand = request.getParameter("brand");

			// Additional fields for online payment
			String esewaId = null;
			String password = null;
			if ("online".equals(paymentType)) {
				esewaId = request.getParameter("esewaId");
				password = request.getParameter("password");
			}

			// Creatting order details
			OrderModel order = new OrderModel();
			order.setUserId(userId);
			order.setShippingAddress(address);
			order.setContactName(name);
			order.setContactPhone(phoneNumber);
			order.setContactEmail(email);
			order.setPaymentMethod(paymentType);
			order.setCategory(category);
			order.setBrand(brand);

			// Processing the order using DAO
			ProductModelDAO productDAO = new ProductModelDAO();
			boolean orderCreated = productDAO.createOrder(order, productCode, quantity, size);

			if (orderCreated) {

				// Redirectting to products page
				response.sendRedirect(request.getContextPath() + "/ProductDetails");
			} else {

				// Redirectting back to product details
				response.sendRedirect(request.getContextPath() + "/ProductDetails?code=" + productCode);
			}

		} catch (Exception e) {
			e.printStackTrace();
			request.getSession().setAttribute("orderMessage", "An error occurred: " + e.getMessage());
			response.sendRedirect(request.getContextPath() + "/ProductDetails");
		}
	}
}