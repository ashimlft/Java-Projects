package Controller;

import DAO.ProductModelDAO;
import Model.ProductModel;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/search")
public class SearchServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String searchName = request.getParameter("searchName");
        String category = request.getParameter("category");
        String priceOrder = request.getParameter("priceOrder");

        // Logging the received parameters
        System.out.println("Search Name: " + searchName);
        System.out.println("Category: " + category);
        System.out.println("Price Order: " + priceOrder);

        // Setting default values if parameters are null or empty
        if (category == null || category.isEmpty()) {
            category = "all"; // Default category
        }
        if (priceOrder == null || priceOrder.isEmpty()) {
            priceOrder = "default"; // Default price order
        }

        ProductModelDAO productDAO = new ProductModelDAO();
        List<ProductModel> productList;

        try {
            productList = productDAO.searchProducts(searchName, category, priceOrder);
            
            // Setting these attributes so they can be accessed in the JSP
            request.setAttribute("productList", productList);
            request.setAttribute("searchName", searchName);
            request.setAttribute("category", category);
            request.setAttribute("priceOrder", priceOrder);
            
            request.getRequestDispatcher("Pages/Product.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace(); // Printting the stack trace to the console
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error retrieving products: " + e.getMessage());
        }
    }
}