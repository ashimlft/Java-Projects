package Controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.ProductModelDAO; // Use existing DAO
import Model.SalesDetailModel;

@WebServlet("/sales")
public class SalesServlet extends HttpServlet {
    private ProductModelDAO productModelDAO;

    public void init() {
        productModelDAO = new ProductModelDAO(); // Initialize with existing DAO
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Retrieving sales details using existing DAO method
        List<SalesDetailModel> salesDetails = productModelDAO.getSalesDetails();
        
        // Setting sales details as an attribute
        request.setAttribute("salesDetails", salesDetails);
        
        // Forwarding to JSP
        request.getRequestDispatcher("Pages/Sales.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Handlling status update
        String orderId = request.getParameter("orderId");
        String newStatus = request.getParameter("orderStatus");

        System.out.println("Received Order ID: " + orderId);
        System.out.println("Received New Status: " + newStatus);

        if (orderId != null && newStatus != null) {
            try {
                int orderIdInt = Integer.parseInt(orderId);
                boolean updated = productModelDAO.updateSalesStatus(orderIdInt, newStatus);

                if (updated) {
                    System.out.println("Status update successful");
                    request.setAttribute("message", "Order status updated successfully.");
                } else {
                    System.out.println("Status update failed");
                    request.setAttribute("error", "Failed to update order status.");
                }
            } catch (NumberFormatException e) {
                System.err.println("Invalid Order ID: " + orderId);
                request.setAttribute("error", "Invalid order ID.");
            }
        } else {
            System.err.println("Order ID or Status is null");
            request.setAttribute("error", "Invalid input.");
        }

        // Reloading sales details and forward
        doGet(request, response);
    }
}