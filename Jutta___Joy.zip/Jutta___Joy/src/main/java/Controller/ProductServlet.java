package Controller; // Declaring this class as part of the 'Controller' package

/* Importing the DAO class for interacting with product-related database operations */
import DAO.ProductModelDAO;

/* Importing the model class representing the product entity */
import Model.ProductModel;

/* Importing servlet-related classes to handle HTTP requests and responses */
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/* Importing classes for handling input-output operations and exceptions */
import java.io.IOException;

/* Importing class for handling SQL-related exceptions */
import java.sql.SQLException;

/* Importing List interface for managing collections of ProductModel objects */
import java.util.List;

/* Declaring the servlet and mapping it to the URL pattern '/Product' */
@WebServlet("/Product")
public class ProductServlet extends HttpServlet {

    // Handling GET requests to fetch and display products
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Creating an instance of the ProductModelDAO to interact with the database
        ProductModelDAO productDAO = new ProductModelDAO();
        
        try {
            // Fetching the list of all products from the database
            List<ProductModel> productList = productDAO.getAllProducts();
            
            // Debugging output to verify the number of products fetched
            System.out.println("Products fetched: " + productList.size());
            
            // Setting the list of products as a request attribute to be accessed in the JSP
            request.setAttribute("productList", productList);
            
            // Forwarding the request to the 'Product.jsp' page for displaying the products
            request.getRequestDispatcher("Pages/Product.jsp").forward(request, response);
        } catch (SQLException | ClassNotFoundException e) {
            // Printing the stack trace for debugging if an exception occurs
            e.printStackTrace();
            
            // Sending an error response to the client if there was a problem fetching the products
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to fetch products.");
        }
    }
}
