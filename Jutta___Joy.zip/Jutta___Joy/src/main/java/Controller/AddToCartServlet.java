package Controller;

import DAO.UserModelDAO;// Importing the data access object for user-related operations

import javax.servlet.ServletException;// Handling servlet-specific exceptions
import javax.servlet.annotation.WebServlet; // Marking this class as a servlet and defining its URL mapping
import javax.servlet.http.*;// Importing classes for HTTP session and request/response handling
import java.io.IOException; // Handling input/output exceptions

@WebServlet("/AddToCart") // Mapping this servlet to the URL "/AddToCart"
public class AddToCartServlet extends HttpServlet {
	 // Handling HTTP POST requests; processes adding a product
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Getting the current session, or null if it doesn't exist
		HttpSession session = request.getSession(false);

		// Getting username from session
		String username = null;

		if (session != null) {
			username = (String) session.getAttribute("username");// Retrieving the username from the session
		}

		// Checking if username is available
		if (username == null || username.isEmpty()) {
			// Redirecting to login if user not logged in
			response.sendRedirect("Pages/Login.jsp");
			return;
		}
		// Getting the product code from the request
		String productCode = request.getParameter("productCode");

		// Getting quantity from form - parse to integer with a default of 1
		int quantity = 1;
		try {
			String quantityParam = request.getParameter("quantity");
			if (quantityParam != null && !quantityParam.isEmpty()) {
				quantity = Integer.parseInt(quantityParam);
			}
		} catch (NumberFormatException e) {
			
		}

		String size = request.getParameter("size");
		if (size == null || size.isEmpty()) {
			// Setting a default size or handle the error appropriately
			size = "Default";
		}

		try {
			// Using the username to add product to cart
			UserModelDAO userDAO = new UserModelDAO();
			boolean success = userDAO.addToCartByUsername(username, productCode, quantity, size);

			if (success) {
				// Setting success message
				session.setAttribute("cartMessage", "Product added to cart successfully!");
			} else {
				// Setting error message
				session.setAttribute("cartMessage", "Failed to add product to cart.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			session.setAttribute("cartMessage", "Error: " + e.getMessage());
		}
	

		// Redirecting back to product details
		response.sendRedirect(request.getContextPath() + "/ProductDetails?code=" + productCode);
	
	}
}