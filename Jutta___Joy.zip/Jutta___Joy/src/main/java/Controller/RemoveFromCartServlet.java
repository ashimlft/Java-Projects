package Controller; // Declaring the class as part of the 'Controller' package

/* Importing classes for handling input-output operations and exceptions during servlet execution */
import java.io.IOException;

/* Importing servlet-related classes to handle HTTP requests, responses, and exceptions */
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/* Importing HttpSession for managing user session data across multiple requests */
import javax.servlet.http.HttpSession;

/* Importing the DAO class for performing database operations related to products */
import DAO.ProductModelDAO;


@WebServlet("/RemoveFromCart")
public class RemoveFromCartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        
        // Checking if user is logged in
        if (userId == null) {
            response.sendRedirect(request.getContextPath() + "/Login");
            return;
        }
        
        String productCode = request.getParameter("productCode");
        
        if (productCode == null || productCode.isEmpty()) {
            request.setAttribute("errorMessage", "Invalid product code");
            request.getRequestDispatcher("/Cart").forward(request, response);
            return;
        }
        
        try {
            // Using ProductModelDAO to remove item from cart
            ProductModelDAO productDAO = new ProductModelDAO();
            boolean removed = productDAO.removeFromCart(userId, productCode);
            
            if (!removed) {
                request.setAttribute("errorMessage", "Failed to remove item from cart");
            }
            
            // Redirecting back to cart page
            request.setAttribute("Sucess", "Remove item from cart");
            response.sendRedirect(request.getContextPath() + "/Cart");
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error removing item: " + e.getMessage());
            request.getRequestDispatcher("/Cart").forward(request, response);
        }
    }
}