package Controller;

import DAO.ProductModelDAO;
import Model.ProductModel;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/AdminProductDetails")
public class AdminProductDetailsServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Getting the product code from the request
        String productCode = request.getParameter("code");
        
        if (productCode == null || productCode.isEmpty()) {
            // If the null product code is provided, redirecting to the products page
            response.sendRedirect(request.getContextPath() + "/AdminProduct");
            return;
        }
        
        try {
            // Fetching product details from database
            ProductModelDAO productDAO = new ProductModelDAO();
            ProductModel product = productDAO.getProductByCode(productCode);
            
            if (product != null) {
                // Setting the product as a request attribute
                request.setAttribute("product", product);
                
                // Forwarding to the product details page
                request.getRequestDispatcher("Pages/AdminProductDetails.jsp").forward(request, response);
            } else {
                // If product not found, setting null product and forward to the page to handle display
                request.setAttribute("product", null);
                request.getRequestDispatcher("Pages/AdminProductDetails.jsp").forward(request, response);
            }
            
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to fetch product details: " + e.getMessage());
        }
    }
}