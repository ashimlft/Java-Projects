package Controller; // Declares the package name as 'Controller'

/* Importing required classes for handling input-output exceptions */
import java.io.IOException;

/* Importing SQL-related classes for database operations and error handling */
import java.sql.SQLException;

/* Importing utility classes for working with collections like List and Map */
import java.util.List;
import java.util.Map;

/* Importing classes for working with Java Servlets */
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import DAO.ProductModelDAO;
import Model.ProductModel;

@WebServlet("/Cart")
public class CartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        
        // Checking if user is logged in
        if (userId == null) {
            response.sendRedirect(request.getContextPath() + "/Login");
            return;
        }
        
        try {
            // Creatting DAO and get cart products with details for the user
            ProductModelDAO productDAO = new ProductModelDAO();
            List<Map<String, Object>> cartItems = productDAO.getCartItemsWithDetails(userId);
            
            // Calculating totals
            double subtotal = 0.0;
            for (Map<String, Object> item : cartItems) {
                double price = (Double) item.get("productPrice");
                int quantity = (Integer) item.get("quantity");
                subtotal += price * quantity;
            }
 
            double total = subtotal ;
            
            // Setting attributes for cart page
            request.setAttribute("cartItems", cartItems);
            request.setAttribute("subtotal", subtotal);
            request.setAttribute("total", total);
            
            // Forwarding to cart.jsp
            request.getRequestDispatcher("Pages/Cart.jsp").forward(request, response);
            
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Failed to retrieve cart items: " + e.getMessage());
            request.getRequestDispatcher("Pages/Cart.jsp").forward(request, response);
        }
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}