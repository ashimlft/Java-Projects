package Controller; // Declares the class as part of the 'Controller' package

/* Importing classes for handling input/output exceptions */
import java.io.IOException;

/* Importing classes for handling SQL database exceptions */
import java.sql.SQLException;

/* Importing collection classes for working with lists and key-value mappings */
import java.util.List;
import java.util.Map;

/* Importing servlet classes for handling HTTP requests and responses */
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/* Importing DAO class for accessing product-related data from the database */
import DAO.ProductModelDAO;


@WebServlet("/GenerateReportServlet")
public class GenerateReportServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ProductModelDAO productModelDAO = new ProductModelDAO();
        try {
            // Getting detailed sales data
            List<Map<String, Object>> salesData = productModelDAO.getSalesReport();
            
            // Calculatting summary statistics
            Map<String, Integer> brandSales = productModelDAO.getBrandSales();
            Map<String, Integer> categorySales = productModelDAO.getCategorySales();
            
            // Setting attributes for JSP
            request.setAttribute("salesData", salesData);
            request.setAttribute("brandSales", brandSales);
            request.setAttribute("categorySales", categorySales);
            
            // Forwarding to sales report JSP
            request.getRequestDispatcher("/Pages/GenerateReport.jsp").forward(request, response);
            
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error generating sales report");
        }
    }
}
