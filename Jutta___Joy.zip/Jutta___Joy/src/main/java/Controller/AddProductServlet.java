package Controller;

import DAO.ProductModelDAO;// Importing the class responsible for managing product data in the database
import Model.ProductModel;// Importing the class defining the structure of a product

import java.io.IOException;// Handling potential input/output exceptions
import java.util.Date;// Enabling the use of date and time functionalities, likely for recording product creation

import javax.servlet.ServletException;// Managing servlet errors
import javax.servlet.annotation.MultipartConfig;// Configuring file uploads
import javax.servlet.annotation.WebServlet;// Defining this as a servlet
import javax.servlet.http.HttpServlet;// Providing HTTP servlet base
import javax.servlet.http.HttpServletRequest;// Representing client request
import javax.servlet.http.HttpServletResponse; // Representing server response
import javax.servlet.http.Part;// Representing uploaded file part
//This servlet handles the "Add Product" form submissions
@WebServlet("/AddProduct") // Maps this servlet to the web address "/AddProduct"
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 1,  // 1MB before writing file to disk
    maxFileSize = 1024 * 1024 * 10,       // max file size 10MB
    maxRequestSize = 1024 * 1024 * 15     // max request size 15MB
)
public class AddProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L; // Defining serial version UID
    // Creating DAO for product operations
    private ProductModelDAO productDAO = new ProductModelDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response)// Handling POST requests
            throws ServletException, IOException { // Handling servlet and IO exceptions

        try {
            request.setCharacterEncoding("UTF-8");// Ensuring UTF-8 encoding

            // Retrieving form fields
            String productName = request.getParameter("productName");
            String brandName = request.getParameter("brandName");
            String size = request.getParameter("size");
            String quantityStr = request.getParameter("quantity");
            String priceStr = request.getParameter("productPrice");
            String productDescription = request.getParameter("productDescription");
            String categoryName = request.getParameter("categoryName"); // Get category name from the form

            // Initializing quantity
            int quantity = 0;
            // Initializing price
            double productPrice = 0.0;
            try {
                quantity = Integer.parseInt(quantityStr);
            } catch (NumberFormatException e) {
                quantity = 0;  // handles error accordingly
            }
            try {
                productPrice = Double.parseDouble(priceStr);
            } catch (NumberFormatException e) {
                productPrice = 0.0; //handles error accordingly
            }

            Part imagePart = request.getPart("image");// Getting uploaded image part

            if (imagePart == null || imagePart.getSize() == 0) {// Checking if image exists
                request.setAttribute("errorMessage", "Image file is required.");
                request.getRequestDispatcher("/Pages/AddProduct.jsp").forward(request, response);
                return;
            }

            // Creating ProductModel object
            ProductModel product = new ProductModel();
            // settinmg productdetails
            product.setProductName(productName);
            product.setBrandName(brandName);
            product.setSize(size);
            product.setQuantity(quantity);
            product.setProductPrice(productPrice);
            product.setProductDescription(productDescription);
            product.setCategoryName(categoryName);
            product.setEntryDate(new Date());

            // Getting the absolute path of the webapp to store images inside the media folder
            String webappPath = "C:/Users/Acer/Documents/adv Java/Jutta___Joy/src/main/webapp/media"; 
            System.out.println("Webapp absolute path: " + webappPath);
            
            boolean saved = productDAO.saveProduct(product, imagePart, webappPath);

            if (saved) { // Checking if save was successful
                request.setAttribute("successMessage", "Product added successfully.");
                request.getRequestDispatcher("/Pages/AddProduct.jsp").forward(request, response);
            } else {
                request.setAttribute("errorMessage", "Failed to add product.");
                request.getRequestDispatcher("/Pages/AddProduct.jsp").forward(request, response);
            }

        } catch (Exception e) {// Handling potential exceptions
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error: " + e.getMessage());
            request.getRequestDispatcher("/Pages/AddProduct.jsp").forward(request, response);
        }
    }
}