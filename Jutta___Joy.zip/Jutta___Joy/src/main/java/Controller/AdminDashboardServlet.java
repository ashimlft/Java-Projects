package Controller;

import java.io.IOException;// Handling input/output exceptions
import java.sql.SQLException;// Handling SQL exceptions

import javax.servlet.ServletException;// Handling servlet-specific exceptions
import javax.servlet.annotation.WebServlet; // Marking this class as a servlet and defining its URL mapping
import javax.servlet.http.HttpServlet; // Providing the base class for creating HTTP servlets
import javax.servlet.http.HttpServletRequest;// Representing the incoming request from a client
import javax.servlet.http.HttpServletResponse;// Representing the outgoing response sent back to the client

import DAO.ProductModelDAO; // Importing the data access object for product-related operations
import DAO.UserModelDAO;// Importing the data access object for user-related operations

@WebServlet("/AdminDashboardServlet")// Mapping this servlet to the URL "/AdminDashboardServlet"
public class AdminDashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;// Defining a unique identifier for this servlet class
    // Handling HTTP GET requests; retrieves and prepares data for the admin
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Creating DAO instances
            ProductModelDAO productDAO = new ProductModelDAO();
            UserModelDAO userDAO = new UserModelDAO();
            
            // Getting dashboard statistics from DAO classes
            int totalProductsSold = productDAO.getTotalProductsSold();
            String topBrand = productDAO.getTopBrand();
            String topCategory = productDAO.getTopCategory();
            int totalUsers = userDAO.getTotalUsers();
            
            // Setting attributes for JSP
            request.setAttribute("totalProductsSold", totalProductsSold);
            request.setAttribute("topBrand", topBrand);
            request.setAttribute("topCategory", topCategory);
            request.setAttribute("totalUsers", totalUsers);
            
            // Forwarding to dashboard JSP
            request.getRequestDispatcher("/Pages/AdminDashboard.jsp").forward(request, response);
            
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error calculating dashboard statistics");
        }
    }
}