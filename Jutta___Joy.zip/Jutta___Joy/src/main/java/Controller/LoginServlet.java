package Controller; // Declaring this class under the 'Controller' package

/* Importing class for handling input-output exceptions during servlet execution */
import java.io.IOException;

/* Importing servlet-related classes for managing HTTP requests and responses */
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/* Importing HttpSession to manage user session data across multiple requests */
import javax.servlet.http.HttpSession;

/* Importing the DAO class for performing user-related database operations */
import DAO.UserModelDAO;

/* Importing the model class representing the user entity */
import Model.UserModel;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
    }
    
    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }
    
    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieving username and password from the request
        String userName = request.getParameter("username");
        String password = request.getParameter("password");
        
        // Creating an instance of UserModelDAO
        UserModelDAO userDAO = new UserModelDAO();
        
        // Validating user credentials
        boolean isValidUser = userDAO.validateUser(userName, password);
        if (isValidUser) {
            HttpSession session = request.getSession();
            session.setAttribute("username", userName);
            
            // Getting user ID and store in session
            int userId = userDAO.getUserIdByUsername(userName);
            if (userId != -1) {
                session.setAttribute("userId", userId);
            }
            
            // Getting full user details and store in session
            UserModel userDetails = userDAO.getUserByUsername(userName);
            if (userDetails != null) {
                session.setAttribute("userDetails", userDetails);
            }
            
            // Successful login
            if (userDAO.isAdmin(userName)) {
                response.sendRedirect("Pages/Admin.jsp");
            } else {
                response.sendRedirect("Pages/User.jsp"); // Redirecting to home page
            }
        } else {
            // Invalid login
            System.out.println(isValidUser);
            request.setAttribute("error", "Invalid username or password");
            request.getRequestDispatcher("Pages/Login.jsp").forward(request, response);
        }
    }
}