package Controller; // Declaring this class as part of the 'Controller' package

/* Importing the DAO class for managing product-related database operations */
import DAO.ProductModelDAO;

/* Importing classes for servlet functionality to handle HTTP requests and responses */
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/* Importing classes for input-output handling and exception management */
import java.io.IOException;

/* Importing class for handling SQL-related exceptions */
import java.sql.SQLException;

@WebServlet("/DeleteProduct")
public class DeleteProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productCode = request.getParameter("product_code");
        ProductModelDAO productModelDAO = new ProductModelDAO();

        try {
            boolean isDeleted = productModelDAO.deleteProduct(productCode);
            if (isDeleted) {
                // Redirecting to AdminProduct.jsp with a success message
                response.sendRedirect("AdminProduct?message=Product deleted successfully.");
            } else {
                // Redirecting to AdminProduct.jsp with an error message
                response.sendRedirect("AdminProduct?message=Failed to delete product.");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("AdminProduct?message=Error occurred while deleting product.");
        }
    }
}