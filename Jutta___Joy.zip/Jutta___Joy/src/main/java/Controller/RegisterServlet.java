package Controller; // Declaring the class under the 'Controller' package

/* Importing classes for handling input-output operations during servlet execution */
import java.io.IOException;

/* Importing Date class to work with date and time */
import java.util.Date;

/* Importing servlet-related classes for managing HTTP requests, responses, and handling exceptions */
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/* Importing DAO class to interact with the user-related database operations */
import DAO.UserModelDAO;

/* Importing the model class representing the user entity */
import Model.UserModel;

@WebServlet("/register")// Declaring this servlet and mapping it to the URL pattern '/register'
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L; // Declaring a serialVersionUID for the servlet class (used for version control)
    // Handling the POST request for user registration
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Collectting user input
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String userName = request.getParameter("userName");
        String email = request.getParameter("email");
        String dob = request.getParameter("dob");
        String address = request.getParameter("address");
        String phoneNumber = request.getParameter("phoneNumber");
        String gender = request.getParameter("gender");  
        String password = request.getParameter("password");
        
        // Setting the current date and time as the user's join date
        Date joinDate = new Date();
        // Assigning a default role to the user (e.g., "USER")
        String role = "USER";
        // Creating a new UserModel object to hold the user's registration details
        UserModel user = new UserModel( firstName,  lastName,  email,  userName,  dob,  address, phoneNumber,  gender,  password,  joinDate,  role);
        UserModelDAO userDAO = new UserModelDAO(); // Creating an instance of UserModelDAO to interact with the database

        if (!userDAO.isUsernameAvailable(userName)) {
            request.setAttribute("errorName", "Username already exists");
            request.getRequestDispatcher("Pages/Register.jsp").forward(request, response);
            return;
        }
        if (!userDAO.isemailAvailable(email)) {
            request.setAttribute("errorEmail", "email already exists");
            request.getRequestDispatcher("Pages/Register.jsp").forward(request, response);
            return;
        }

        if (userDAO.registerUser(user)) {
            response.sendRedirect("Pages/Login.jsp");
        } else {
            request.getRequestDispatcher("Pages/Register.jsp").forward(request, response);
        }
    }
}
