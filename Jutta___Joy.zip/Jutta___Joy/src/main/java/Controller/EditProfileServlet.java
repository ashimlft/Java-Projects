package Controller; // Declaring this class as part of the 'Controller' package

/* Importing class for handling input and output exceptions */
import java.io.IOException;

/* Importing classes for servlet operations and exception handling */
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession; // Importing session management class for maintaining user data across requests

/* Importing the DAO class responsible for user-related database operations */
import DAO.UserModelDAO;

/* Importing the model class that represents the user entity */
import Model.UserModel;


@WebServlet("/EditProfileServlet")
public class EditProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        
        if (username == null || username.isEmpty()) {
            // Redirectting to login if user is not logged in
            response.sendRedirect("Login.jsp");
            return;
        }
        
        // Getting the user data
        UserModelDAO userDAO = new UserModelDAO();
        UserModel user = userDAO.getUserByUsername(username);
        if (user != null) {
            // Setting user data as attributes
            request.setAttribute("user", user);
            request.getRequestDispatcher("/Pages/EditProfile.jsp").forward(request, response);
        } else {
            // Handling case where user data couldn't be retrieved
            request.setAttribute("errorMessage", "Failed to retrieve user data. Please try again.");
            request.getRequestDispatcher("/Pages/EditProfile.jsp").forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        
        if (username == null || username.isEmpty()) {
            // Redirectting to login if user is not logged in
            response.sendRedirect("/Pages/Login.jsp");
            return;
        }
        
        // Getting form parameters
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String email = request.getParameter("email");
        String dob = request.getParameter("dob");
        String address = request.getParameter("address");
        String phoneNumber = request.getParameter("phoneNumber");
        String gender = request.getParameter("gender");
        
        // Validatting input
        if (firstName == null || lastName == null || email == null || dob == null || 
            address == null || phoneNumber == null || gender == null ||
            firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || dob.isEmpty() ||
            address.isEmpty() || phoneNumber.isEmpty() || gender.isEmpty()) {
            
            request.setAttribute("errorMessage", "All fields are required.");
            request.getRequestDispatcher("/Pages/EditProfile.jsp").forward(request, response);
            return;
        }
        
        // Getting current user data
        UserModelDAO userDAO = new UserModelDAO();
        UserModel currentUser = userDAO.getUserByUsername(username);
        
        // Creatting updated user model
        UserModel updatedUser = new UserModel(
            firstName,
            lastName,
            email,
            username,
            dob,
            address,
            phoneNumber,
            gender,
            null, // No need to update password here Password is passing as null
            currentUser.getJoinDate(),
            currentUser.getRole()
        );
        
        // Updatting user profile
        boolean success = userDAO.updateUser(updatedUser);
        
        if (success) {
            // Getting updated user data
            UserModel user = userDAO.getUserByUsername(username);
            
            // Updatting the session with the new user details
            if (user != null) {
                session.setAttribute("userDetails", user);
                
                // Setting success message and user role as request attributes
                request.setAttribute("successMessage", "Profile updated successfully!");
                request.setAttribute("userRole", user.getRole());
                
                // Forwarding to the JSP to show the success message
                request.getRequestDispatcher("/Pages/EditProfile.jsp").forward(request, response);
            } else {
                // Fallbacking if user data isn't available
                request.setAttribute("errorMessage", "Profile updated but couldn't retrieve updated data.");
                request.getRequestDispatcher("/Pages/EditProfile.jsp").forward(request, response);
            }
        } else {
            // Setting error message as request attribute
            request.setAttribute("errorMessage", "Failed to update profile. Please try again.");
            request.getRequestDispatcher("/Pages/EditProfile.jsp").forward(request, response);
        }
    }
}