package Controller; // Declaring the package name as 'Controller'

/* Importing the Data Access Object (DAO) class for interacting with product data */
import DAO.ProductModelDAO;

/* Importing the model class representing the product entity */
import Model.ProductModel;

/* Importing servlet-related classes for creating and managing HTTP requests and responses */
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/* Importing classes for handling input-output operations and exceptions */
import java.io.IOException;

/* Importing class for handling SQL-related exceptions */
import java.sql.SQLException;

/* Importing List interface for handling collections of objects */
import java.util.List;


@WebServlet("/AdminProduct")
public class AdminProductServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ProductModelDAO productDAO = new ProductModelDAO();
        try {
            List<ProductModel> productList = productDAO.getAllProducts();
            System.out.println("Products fetched: " + productList.size()); // Debug output
            request.setAttribute("productList", productList);
            request.getRequestDispatcher("Pages/AdminProduct.jsp").forward(request, response);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to fetch products.");
        }
    }
}
