package Controller; // Declaring this servlet class as part of the 'Controller' package

/* Importing classes for handling input-output exceptions and SQL errors */
import java.io.IOException;
import java.sql.SQLException;

/* Importing Map interface for storing and managing key-value pairs (e.g., product data) */
import java.util.Map;

/* Importing servlet-related classes for handling HTTP requests, responses, and sessions */
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/* Importing the DAO class to interact with product-related database operations */
import DAO.ProductModelDAO;

/* Importing the model class representing a user entity */
import Model.UserModel;


@WebServlet("/OrderDetailServlet")
public class OrderDetailServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    public OrderDetailServlet() {
        super();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        UserModel userDetails = (UserModel) session.getAttribute("userDetails");
        
        if (userDetails == null) {
            // User not logged in on this case redirectting to login page
            response.sendRedirect(request.getContextPath() + "/Pages/Login.jsp");
            return;
        }
        
        String orderIdParam = request.getParameter("orderId");
        if (orderIdParam == null || orderIdParam.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/OrderHistoryServlet");
            return;
        }
        
        try {
            int orderId = Integer.parseInt(orderIdParam);
            
            ProductModelDAO productDao = new ProductModelDAO();
            Map<String, Object> orderDetails = productDao.getOrderDetails(orderId);
            
            // Verifying this order belongs to the current user (security check)
            if (orderDetails != null && !orderDetails.isEmpty()) {
                request.setAttribute("orderDetails", orderDetails);
                request.getRequestDispatcher("/Pages/OrderDetails.jsp").forward(request, response);
            } else {
                // Order not found or doesn't belong to user
                response.sendRedirect(request.getContextPath() + "/OrderHistoryServlet");
            }
            
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/OrderHistoryServlet");
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred while retrieving order details: " + e.getMessage());
            request.getRequestDispatcher("/Pages/Error.jsp").forward(request, response);
        }
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}