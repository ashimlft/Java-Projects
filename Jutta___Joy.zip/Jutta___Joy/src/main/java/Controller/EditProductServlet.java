package Controller; // Declaring the package as 'Controller'

/* Importing DAO class for interacting with product-related data in the database */
import DAO.ProductModelDAO;

/* Importing model class that represents the product entity */
import Model.ProductModel;

/* Importing servlet classes for handling HTTP requests and multipart form data */
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/* Importing classes for exception handling and I/O operations */
import java.io.IOException;
import java.sql.SQLException;

/* Declaring the servlet and mapping it to the URL pattern '/EditProductServlet' */
@WebServlet("/EditProductServlet")
@MultipartConfig // Enables support for multipart/form-data for file upload
public class EditProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	// Handles POST requests
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");// Ensures proper handling of non-ASCII characters
		// Retrieving form parameters from the request
		String productCode = request.getParameter("product_code");
		String name = request.getParameter("name");
		String description = request.getParameter("description");
		String size = request.getParameter("size");
		String categoryName = request.getParameter("categoryName");
		String brandName = request.getParameter("brandName");
		String priceStr = request.getParameter("price");
		String stockStr = request.getParameter("stock");

		double price = 0;
		int stock = 0;
		// Parsing numeric fields with error handling
		try {
			price = Double.parseDouble(priceStr);
			stock = Integer.parseInt(stockStr);
		} catch (NumberFormatException e) {
			request.setAttribute("errorMessage", "Invalid number format for price or stock.");
			request.getRequestDispatcher("Pages/EditProduct.jsp?product_code=" + productCode).forward(request,
					response);
			return;
		}
		// Handling uploaded image file
		Part imagePart = request.getPart("image");
		// Determining the path to store uploaded images
		String webappPath = request.getServletContext().getRealPath("") + "media";
		// Creating and populating the ProductModel object
		ProductModel product = new ProductModel();
		product.setProductCode(productCode);
		product.setProductName(name);
		product.setProductDescription(description);
		product.setSize(size);
		product.setCategoryName(categoryName);
		product.setBrandName(brandName);
		product.setProductPrice(price);
		product.setQuantity(stock);
		// Creating DAO instance to perform database update
		ProductModelDAO dao = new ProductModelDAO();

		try {
			// Attempting to update product data and image
			boolean success = dao.updateProduct(product, imagePart, webappPath);

			if (success) {
				request.setAttribute("successMessage", "Product updated successfully.");
			} else {
				request.setAttribute("errorMessage", "Failed to update the product.");
			}
		} catch (SQLException | ClassNotFoundException e) {
			// Logging and handling any exceptions
			e.printStackTrace();
			request.setAttribute("errorMessage", "An error occurred while updating the product: " + e.getMessage());
		}
		// Forwarding back to the edit page with the same product code
		request.getRequestDispatcher("Pages/EditProduct.jsp?product_code=" + productCode).forward(request, response);
	}
}