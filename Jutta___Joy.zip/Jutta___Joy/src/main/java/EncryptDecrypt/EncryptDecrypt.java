package EncryptDecrypt;// Declaring the class under the 'EncryptDecrypt' package

//Importing necessary classes for encryption, decryption, and encoding
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.spec.KeySpec;
import java.util.Base64;

public class EncryptDecrypt {
	// Secret key and salt used for encryption and decryption
	private static final String SECRET_KEY = "my_super_secret_key";
	private static final String SALT = "ssshhhhhhhhhhh!!!!";
	// Method to encrypt a given string using AES encryption with CBC mode and PKCS5Padding
	public String encrypt(String strToEncrypt) {
		try {
			// Defining the initialization vector (IV), set to 16 bytes (all zeros here)
			byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			IvParameterSpec ivspec = new IvParameterSpec(iv);
			// Creating a key specification using PBKDF2 with HmacSHA256 algorithm
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			KeySpec spec = new PBEKeySpec(SECRET_KEY.toCharArray(), SALT.getBytes(), 65536, 256);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
			// Initializing the cipher for encryption using AES with CBC mode and PKCS5 padding
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);
			// Encrypting the input string and encoding it as a Base64 string
			return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8)));
		} catch (Exception e) {
			 // Printing any exceptions that occur during encryption
			System.out.println("Error while encrypting: " + e.toString());
		}
		return null; // Returning null in case of an error
	}
	 // Method to decrypt a given Base64 encoded string using AES decryption
	public String decrypt(String input) {
		try {
			 // Defining the initialization vector (IV), set to 16 bytes (all zeros here)
			byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			IvParameterSpec ivspec = new IvParameterSpec(iv);
			// Creating a key specification using PBKDF2 with HmacSHA256 algorithm
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			KeySpec spec = new PBEKeySpec(SECRET_KEY.toCharArray(), SALT.getBytes(), 65536, 256);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");

            // Initializing the cipher for decryption using AES with CBC mode and PKCS5 padding
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
			return new String(cipher.doFinal(Base64.getDecoder().decode(input)));
		} catch (Exception e) {
			System.out.println("Error while decrypting: " + e.toString());
		}
		return null; // Returning null in case of an error
	}
	// Main method to test encryption and decryption
	public static void main(String[] args) {
		EncryptDecrypt ed = new EncryptDecrypt();
		String decryptedText = ed.decrypt("QvU8FJFpdtLhih92jAUcmQ=="); // Decrypting an encrypted string
		
		System.out.println(decryptedText); // Printing the decrypted text
	}
}