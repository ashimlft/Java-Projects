package Model;

public class SalesDetailModel {
//	Defining constructor
    private int orderId;
    private String contactName;
    private String shippingAddress;
    private String contactEmail;
    private String contactPhone;
    private String orderStatus;
    private String productName;
    private String productCode;
    private int userId; 

    // Default constructor
    public SalesDetailModel() {}

 // initializing parameterized constructor
    public SalesDetailModel(int orderId, String contactName, String shippingAddress, 
                       String contactEmail, String contactPhone, String orderStatus, 
                       String productName, String productCode, int userId) {
        this.orderId = orderId;
        this.contactName = contactName;
        this.shippingAddress = shippingAddress;
        this.contactEmail = contactEmail;
        this.contactPhone = contactPhone;
        this.orderStatus = orderStatus;
        this.productName = productName;
        this.productCode = productCode;
        this.userId = userId;
    }

    // Getters and setters
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(String shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }
}