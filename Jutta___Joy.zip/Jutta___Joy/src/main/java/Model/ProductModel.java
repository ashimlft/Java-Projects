package Model;

import java.util.Date;

public class ProductModel {
//	Defining variables
    private String productName;
    private String productDescription;
    private String size;
    private String categoryName;
    private String brandName;
    private double productPrice;
    private int quantity;
    private String image;
    private Date entryDate;
    private String productCode;
//    Default constructor
    public ProductModel() {
    }
// initializing parameterized constructor
    public ProductModel(String productName, String productDescription, String size, String categoryName, String brandName,
    		double productPrice, int quantity, String image, Date entryDate, String productCode) {
        this.productName = productName;
        this.productDescription = productDescription;
        this.size = size;
        this.categoryName = categoryName;
        this.brandName = brandName;
        this.productPrice = productPrice;
        this.quantity = quantity;
        this.image = image;
        this.entryDate = entryDate;
        this.productCode = productCode;
    }

    // Getters and Setters
    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }
}
