package Filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.UserModelDAO; // Import your DAO class

@WebFilter(urlPatterns = { "/Pages/Login.jsp",
		// Admin URLs
		"/Pages/Admin.jsp", "/Pages/AdminDashboard.jsp", "/Pages/AddProduct.jsp", "/Pages/EditProduct.jsp",
		"/AdminProductDetails", "/AdminProduct", "/GenerateReportServlet", "/AdminUserManagement",
		"/AdminOrderManagement", "/AdminInventoryManagement", "/sales",

		// User URLs
		"/Pages/User.jsp", "/Cart", "/ProductDetails", "/Onlinepayment.jsp", "/CashPayment.jsp",
		"/OrderDetailServlet", "/OrderHistoryServlet", "/UserProfile", "/UpdateProfile" })
public class AuthenticationFilter implements Filter {
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		System.out.println("AuthenticationFilter initialized");
	}

	@Override
	public void destroy() {
		System.out.println("AuthenticationFilter destroyed");
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;

		String uri = req.getRequestURI();

		// Checking if user session exists and if user is logged in
		HttpSession session = req.getSession(false);
		boolean loggedIn = session != null && session.getAttribute("username") != null;

		// Allowing access to the login page and login servlet for non-logged-in users
		if (!loggedIn) {
			if (uri.endsWith("Login.jsp") || uri.endsWith("LoginServlet")) {
				chain.doFilter(request, response);
			} else {
				res.sendRedirect(req.getContextPath() + "/Pages/Login.jsp");
			}
			return;
		}

		// User is logged in - determining user role
		String username = (String) session.getAttribute("username");
		UserModelDAO userDAO = new UserModelDAO();
		boolean isAdmin = userDAO.isAdmin(username);

		// Preventing logged-in users from accessing the login page directly
		if (uri.endsWith("Login.jsp")) {
			if (isAdmin) {
				res.sendRedirect(req.getContextPath() + "/Pages/Admin.jsp");
			} else {
				res.sendRedirect(req.getContextPath() + "/Pages/User.jsp");
			}
			return;
		}

		// Role-based access control
		if (isAdmin) {

			if (uri.endsWith("Admin.jsp") || uri.endsWith("AdminDashboard.jsp") || uri.endsWith("AddProduct.jsp")
					|| uri.endsWith("/AdminProductDetails") || uri.endsWith("Admin.jsp")
					|| uri.endsWith("/AdminProduct") || uri.endsWith("EditProduct.jsp")
					|| uri.endsWith("/GenerateReportServlet") || uri.endsWith("/sales")) {
				chain.doFilter(request, response);
			} else {
				// Admin trying to access User.jsp or any other restricted page - redirect to
				// Admin.jsp
				res.sendRedirect(req.getContextPath() + "/Pages/Admin.jsp");
			}
		} else {

			if (uri.endsWith("User.jsp")|| uri.endsWith("User.jsp")
					|| uri.endsWith("/Cart") || uri.endsWith("/ProductDetails") || uri.endsWith("Onlinepayment.jsp")
					|| uri.endsWith("CashPayment.jsp") || uri.endsWith("/OrderDetailServlet")
					|| uri.endsWith("/OrderHistoryServlet")) {
				chain.doFilter(request, response);
			} else {
				// User trying to access Admin.jsp or any other restricted page - redirect to
				// User.jsp
				res.sendRedirect(req.getContextPath() + "/Pages/User.jsp");
			}
		}
	}
}