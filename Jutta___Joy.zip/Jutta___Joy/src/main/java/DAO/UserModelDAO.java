package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import DataBase.DataBaseConnection; // Import your existing DataBaseConnection class
import EncryptDecrypt.EncryptDecrypt;
import Model.UserModel;

public class UserModelDAO {
    // Method to check if a username is available
    public boolean isUsernameAvailable(String username) {
        String sql = "SELECT COUNT(user_name) FROM user WHERE user_name = ?";
        
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
             
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();
            
            if (resultSet.next()) {
                return resultSet.getInt(1) == 0; // Return true if username is available
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return false; // Return false if an error occurs
    }
    
    public boolean isemailAvailable(String email) {
        String sql = "SELECT COUNT(email) FROM user WHERE email = ?";
        
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
             
            statement.setString(1, email);
            ResultSet resultSet = statement.executeQuery();
            
            if (resultSet.next()) {
                return resultSet.getInt(1) == 0; // Return true if username is available
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return false; // Return false if an error occurs
    }

    // Method to register a new user
    public boolean registerUser (UserModel user) {
        String sql = "INSERT INTO User (first_name, last_name, email, user_name, password, address, phone_number, gender, dob, joined_date, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        EncryptDecrypt encryptDecrypt = new EncryptDecrypt(); // Create an instance of EncryptDecrypt

        // Encrypt the password before saving
        String encryptedPassword = encryptDecrypt.encrypt(user.getPassword());
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
         
            // Setting parameters for the prepared statement
            statement.setString(1, user.getFirstName());
            statement.setString(2, user.getLastName());
            statement.setString(3, user.getEmail());
            statement.setString(4, user.getUserName()); 
            statement.setString(5, encryptedPassword); //hash this password
            statement.setString(6, user.getAddress());
            statement.setString(7, user.getPhoneNumber());
            statement.setString(8, user.getGender());
            statement.setString(9, user.getDob());
            statement.setDate(10, new java.sql.Date(user.getJoinDate().getTime())); // Converting Date to SQl Date format
            statement.setString(11, user.getRole());

            // Execute the update and return true if it is successful
            int rowsInserted = statement.executeUpdate();
            return rowsInserted > 0; // Returning true if the user was successfully registered
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return false; // Returning false if an error occurs
        }
    }
    
    // Method to validate user credentials
    public boolean validateUser (String userName, String password) {
        String sql = "SELECT user_name,password FROM user WHERE user_name = ?";
        EncryptDecrypt encryptDecrypt = new EncryptDecrypt(); // Creating an instance of EncryptDecrypt

        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
             
            statement.setString(1,userName);
            ResultSet resultSet = statement.executeQuery();
            
            if (resultSet.next()) {
      
                String encryptedPassword = resultSet.getString("password");
                // Decrypt the stored password for comparison
                String decryptedPassword = encryptDecrypt.decrypt(encryptedPassword);
                
                System.out.println("Decrypted Password: " + decryptedPassword);
                System.out.println("Provided Password: " + password);
                
                // Checking if the decrypted password matches the provided passwords
                return  decryptedPassword != null && decryptedPassword.equals(password);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return false; // Returning false if credentials are invalid
    }
    
    // Method to check if a user is an admin
    public boolean isAdmin(String username) {
        String sql = "SELECT role FROM user WHERE user_name = ?";
        
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
             
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();
            
            if (resultSet.next()) {
                String role = resultSet.getString("role");
                return role != null && role.equalsIgnoreCase("admin");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return false; // Returning false if user doesn't exist or an error occurs
    }
    
    // Method to get user details by username
    public UserModel getUserByUsername(String username) {
        String sql = "SELECT * FROM user WHERE user_name = ?";
        
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
             
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();
            
            if (resultSet.next()) {
                // Creating the UserModel instance with user_id included
                UserModel user = new UserModel(
                    resultSet.getString("first_name"),
                    resultSet.getString("last_name"),
                    resultSet.getString("email"),
                    resultSet.getString("user_name"),
                    resultSet.getString("dob"),
                    resultSet.getString("address"),
                    resultSet.getString("phone_number"),
                    resultSet.getString("gender"),
                    null, //Setting the password null for security reasons
                    resultSet.getDate("joined_date"),
                    resultSet.getString("role")
                );
                
                // Setting the user ID 
                user.setUserId(resultSet.getInt("user_id"));
                
                return user;
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null; // Returning null if user not found or an error occurs
    }
    
    // Method to get user ID by username
    public int getUserIdByUsername(String username) {
        String sql = "SELECT user_id FROM user WHERE user_name = ?";
        
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
             
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();
            
            if (resultSet.next()) {
                return resultSet.getInt("user_id");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return -1; // Returning -1 if user not found or an error occurs
    }
//    Method to update User details
    public boolean updateUser(UserModel user) {
        String sql = "UPDATE user SET first_name = ?, last_name = ?, email = ?, address = ?, " +
                     "phone_number = ?, gender = ?, dob = ? WHERE user_name = ?";
        
        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
             
            // Setting parameters for the prepared statement
            statement.setString(1, user.getFirstName());
            statement.setString(2, user.getLastName());
            statement.setString(3, user.getEmail());
            statement.setString(4, user.getAddress());
            statement.setString(5, user.getPhoneNumber());
            statement.setString(6, user.getGender());
            statement.setString(7, user.getDob());
            statement.setString(8, user.getUserName());
            
            // Executing the update and return true if successful
            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0; // Returning true if the user was successfully updated
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return false; // Returning false if an error occurs
        }
    }
    
    public boolean addToCartByUsername(String username, String productCode, int quantity, String size) 
            throws SQLException, ClassNotFoundException {
        
        Connection con = null;
        PreparedStatement userIdStmt = null;
        ResultSet rs = null;
        
        try {
            con = DataBaseConnection.getConnection();
            con.setAutoCommit(false); // Starting transaction
            
            // Getting the user ID from the username
            String getUserIdSql = "SELECT user_id FROM user WHERE user_name = ?";
            userIdStmt = con.prepareStatement(getUserIdSql);
            userIdStmt.setString(1, username);
            rs = userIdStmt.executeQuery();
            
            if (!rs.next()) {
                // User not found
                return false;
            }
            
            int userId = rs.getInt("user_id");
            
            // Use the existing method to add to cart now that we have the userId
            ProductModelDAO productDAO = new ProductModelDAO();
            boolean success = productDAO.addToCart(userId, productCode, quantity, size);
            
            con.commit();
            return success;
            
        } catch (SQLException e) {
            if (con != null) {
                try {
                    con.rollback(); // Rollback transaction on error
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
            throw e;
        } finally {
            // Closing all resources
            try {
                if (rs != null) rs.close();
                if (userIdStmt != null) userIdStmt.close();
                if (con != null) {
                    con.setAutoCommit(true); // Reset auto-commit
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
 // Method to get total users count
    public int getTotalUsers() throws SQLException, ClassNotFoundException {
        int totalUsers = 0;
        String sql = "SELECT COUNT(*) as user_count FROM user";
        
        try (Connection con = DataBaseConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            if (rs.next()) {
                totalUsers = rs.getInt("user_count");
            }
        }
        return totalUsers;
    }
}