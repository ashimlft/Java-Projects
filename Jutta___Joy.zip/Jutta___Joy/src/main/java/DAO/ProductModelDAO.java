package DAO;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.Part;

import DataBase.DataBaseConnection; // Assuming you have a DB connection utility class
import Model.OrderModel;
import Model.ProductModel;
import Model.SalesDetailModel;

public class ProductModelDAO {

	// Method to save product details into database
	public boolean saveProduct(ProductModel product, Part imagePart, String webappPath)
			throws IOException, SQLException, ClassNotFoundException {
		// Saving image file to media folder inside webapp
		File mediaDir = new File(webappPath);
		if (!mediaDir.exists()) {
			mediaDir.mkdirs();
		}

		// Generating unique file name using currentTimeMillis + original filename for
		// avoiding conflicts
		String fileName = System.currentTimeMillis() + "_" + getFileName(imagePart);

		// Full path on disk to save the image
		File file = new File(mediaDir, fileName);

		// Copying the uploaded file to the disk location
		try (InputStream input = imagePart.getInputStream(); FileOutputStream output = new FileOutputStream(file)) {

			byte[] buffer = new byte[1024];
			int bytesRead;
			while ((bytesRead = input.read(buffer)) != -1) {
				output.write(buffer, 0, bytesRead);
			}
		}

		// Storing only the relative path in the database (e.g. "media/filename.jpg")
		String relativePath = "media/" + fileName;

		// Generating product_code
		String productCode = generateProductCode();

		// Updating SQL to include category column and product_code
		String sql = "INSERT INTO product (product_price, entry_date, product_name, product_description, size, stock, brand_name, category, product_code, image) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try (Connection con = DataBaseConnection.getConnection();
				PreparedStatement statement = con.prepareStatement(sql)) {

			statement.setDouble(1, product.getProductPrice()); // product_price
			statement.setDate(2, new java.sql.Date(System.currentTimeMillis())); // entry_date
			statement.setString(3, product.getProductName()); // product_name
			statement.setString(4, product.getProductDescription()); // product_description
			statement.setString(5, product.getSize()); // size
			statement.setInt(6, product.getQuantity()); // stock
			statement.setString(7, product.getBrandName()); // brand_name
			statement.setString(8, product.getCategoryName()); // category
			statement.setString(9, productCode); // product_code
			statement.setString(10, relativePath); // image

			int rowsInserted = statement.executeUpdate();
			return rowsInserted > 0;
		}
	}
// Method to generate product code uniquily
	public String generateProductCode() throws SQLException, ClassNotFoundException {
		String SQL = "SELECT MAX(product_id) AS max_id FROM product";
		try (Connection con = DataBaseConnection.getConnection();
				PreparedStatement statement = con.prepareStatement(SQL);
				ResultSet resultSet = statement.executeQuery()) {
			if (resultSet.next()) {
				int maxId = resultSet.getInt("max_id");
				if (resultSet.wasNull()) {
					// If no products in table byb default pd-1
					return "Pd-1";
				} else {
					return "Pd-" + (maxId + 1);
				}
			}
		}
		// Default if resultSet empty for some reason
		return "Pd-1";
	}
// Method to get all the product details.
	public List<ProductModel> getAllProducts() throws SQLException, ClassNotFoundException {
		List<ProductModel> productList = new ArrayList<>();
		String sql = "SELECT * FROM product";

		try (Connection con = DataBaseConnection.getConnection();
				PreparedStatement statement = con.prepareStatement(sql);
				ResultSet resultSet = statement.executeQuery()) {

			while (resultSet.next()) {
				ProductModel product = new ProductModel();
				product.setProductName(resultSet.getString("product_name"));
				product.setProductDescription(resultSet.getString("product_description"));
				product.setBrandName(resultSet.getString("brand_name"));
				product.setProductPrice(resultSet.getDouble("product_price"));
				product.setQuantity(resultSet.getInt("stock"));
				product.setImage(resultSet.getString("image"));
				product.setEntryDate(resultSet.getDate("entry_date"));
				product.setCategoryName(resultSet.getString("category"));
				product.setProductCode(resultSet.getString("product_code")); 

				productList.add(product);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return productList;
	}
//  Method to get product details from product code.
	public ProductModel getProductByCode(String productCode) throws SQLException, ClassNotFoundException {
		String sql = "SELECT * FROM product WHERE product_code = ?";
		try (Connection con = DataBaseConnection.getConnection();
				PreparedStatement statement = con.prepareStatement(sql)) {
			statement.setString(1, productCode);
			try (ResultSet resultSet = statement.executeQuery()) {
				if (resultSet.next()) {
					ProductModel product = new ProductModel();
					product.setProductName(resultSet.getString("product_name"));
					product.setProductDescription(resultSet.getString("product_description"));
					product.setBrandName(resultSet.getString("brand_name"));
					product.setProductPrice(resultSet.getDouble("product_price"));
					product.setQuantity(resultSet.getInt("stock"));
					product.setImage(resultSet.getString("image"));
					product.setEntryDate(resultSet.getDate("entry_date"));
					product.setCategoryName(resultSet.getString("category"));
					product.setSize(resultSet.getString("size"));
					product.setProductCode(resultSet.getString("product_code"));
					return product;
				}
			}
		}
		return null;
	}
// Method to update product details
	public boolean updateProduct(ProductModel product, Part imagePart, String webappPath)
			throws IOException, SQLException, ClassNotFoundException {
		String relativePath = null;// To hold the relative path of the uploaded image

	    // Check if an image file has been provided and has content
		if (imagePart != null && imagePart.getSize() > 0) {
			File mediaDir = new File(webappPath);
			if (!mediaDir.exists()) {
				mediaDir.mkdirs();
			}
			  // Generate a unique filename using current time and original file name
			String fileName = System.currentTimeMillis() + "_" + getFileName(imagePart);
			File file = new File(mediaDir, fileName);
			  // Write image content to the file
			try (InputStream input = imagePart.getInputStream(); FileOutputStream output = new FileOutputStream(file)) {

				byte[] buffer = new byte[1024];
				int bytesRead;
				while ((bytesRead = input.read(buffer)) != -1) {
					output.write(buffer, 0, bytesRead);
				}
			}
			// Store relative path to be saved in the database
			relativePath = "media/" + fileName;
		}

		String sql;
		 // SQL query with or without image field depending on whether new image was uploaded
		if (relativePath != null) {
			sql = "UPDATE product SET product_price = ?, product_name = ?, product_description = ?, size = ?, stock = ?, brand_name = ?, category = ?, image = ? WHERE product_code = ?";
		} else {
			sql = "UPDATE product SET product_price = ?, product_name = ?, product_description = ?, size = ?, stock = ?, brand_name = ?, category = ? WHERE product_code = ?";
		}
		// Try-with-resources to auto-close DB resources
		try (Connection con = DataBaseConnection.getConnection();
				PreparedStatement statement = con.prepareStatement(sql)) {
			// Setting parameters for the prepared statement
			statement.setDouble(1, product.getProductPrice());
			statement.setString(2, product.getProductName());
			statement.setString(3, product.getProductDescription());
			statement.setString(4, product.getSize());
			statement.setInt(5, product.getQuantity());
			statement.setString(6, product.getBrandName());
			statement.setString(7, product.getCategoryName());

			if (relativePath != null) {
				statement.setString(8, relativePath); // Set image path
				statement.setString(9, product.getProductCode());
			} else {
				statement.setString(8, product.getProductCode());
			}

			int rowsUpdated = statement.executeUpdate();
			return rowsUpdated > 0;
		}
	}
// Method to delete product 
	public boolean deleteProduct(String productCode) throws SQLException, ClassNotFoundException {
		String sql = "DELETE FROM product WHERE product_code = ?";
		try (Connection con = DataBaseConnection.getConnection();
				PreparedStatement statement = con.prepareStatement(sql)) {
			statement.setString(1, productCode);
			int rowsDeleted = statement.executeUpdate();
			return rowsDeleted > 0;
		}
	}

	public List<ProductModel> searchProducts(String searchName, String category, String priceOrder) throws SQLException, ClassNotFoundException {
	    List<ProductModel> productList = new ArrayList<>();
	    StringBuilder sql = new StringBuilder("SELECT * FROM product WHERE product_name LIKE ?");

	    // Checking if category is not "all" and append to SQL
	    if (!category.equals("all")) {
	        sql.append(" AND category = ?");
	    }

	    // Append price order if specified
	    if (priceOrder.equals("low-to-high")) {
	        sql.append(" ORDER BY product_price ASC");
	    } else if (priceOrder.equals("high-to-low")) {
	        sql.append(" ORDER BY product_price DESC");
	    }

	    try (Connection con = DataBaseConnection.getConnection();
	         PreparedStatement statement = con.prepareStatement(sql.toString())) {
	        statement.setString(1, "%" + searchName + "%"); // Bind searchName
	        if (!category.equals("all")) {
	            statement.setString(2, category); // Bind category if not "all"
	        }

	        try (ResultSet resultSet = statement.executeQuery()) {
	            while (resultSet.next()) {
	                ProductModel product = new ProductModel();
	                product.setProductName(resultSet.getString("product_name"));
	                product.setProductDescription(resultSet.getString("product_description"));
	                product.setBrandName(resultSet.getString("brand_name"));
	                product.setProductPrice(resultSet.getDouble("product_price"));
	                product.setQuantity(resultSet.getInt("stock"));
	                product.setImage(resultSet.getString("image"));
	                product.setEntryDate(resultSet.getDate("entry_date"));
	                product.setCategoryName(resultSet.getString("category"));
	                product.setProductCode(resultSet.getString("product_code"));

	                productList.add(product);
	            }
	        }
	    }
	    return productList;
	}
	// Method to display new arrival product on home page
	public List<ProductModel> getNewArrivals(int limit) throws SQLException, ClassNotFoundException {
	    List<ProductModel> productList = new ArrayList<>();
	    
	    // Fixed SQL query - using a numeric literal instead of a parameter placeholder
	    String sql = "SELECT * FROM product ORDER BY entry_date DESC LIMIT " + limit;
	    
	    try (Connection con = DataBaseConnection.getConnection();
	         PreparedStatement statement = con.prepareStatement(sql);
	         ResultSet resultSet = statement.executeQuery()) {
	        
	        System.out.println("Debug - Executing query: " + sql);
	        
	        while (resultSet.next()) {
	            ProductModel product = new ProductModel();
	            product.setProductName(resultSet.getString("product_name"));
	            product.setProductDescription(resultSet.getString("product_description"));
	            product.setBrandName(resultSet.getString("brand_name"));
	            product.setProductPrice(resultSet.getDouble("product_price"));
	            product.setQuantity(resultSet.getInt("stock"));
	            product.setImage(resultSet.getString("image"));
	            product.setEntryDate(resultSet.getDate("entry_date"));
	            product.setCategoryName(resultSet.getString("category"));
	            product.setProductCode(resultSet.getString("product_code"));
	            
	            productList.add(product);
	        }
	        
	        System.out.println("Debug - Retrieved " + productList.size() + " products");
	    }
	    
	    return productList;
	}

	// Method to add product to user's cart
	public boolean addToCart(int userId, String productCode, int quantity, String size) throws SQLException, ClassNotFoundException {
	    Connection con = null;
	    PreparedStatement cartIdStmt = null;
	    PreparedStatement insertCartStmt = null;
	    PreparedStatement productIdStmt = null;
	    PreparedStatement checkStmt = null;
	    PreparedStatement insertStmt = null;
	    PreparedStatement updateStmt = null;
	    ResultSet rs = null;
	    ResultSet generatedKeys = null;
	    
	    try {
	        con = DataBaseConnection.getConnection();
	        con.setAutoCommit(false); // Start transaction
	        
	        //  Checking if cart exists for user and get cart_id
	        int cartId = 0;
	        String getCartIdSql = "SELECT cart_id FROM Cart WHERE user_id = ?";
	        cartIdStmt = con.prepareStatement(getCartIdSql);
	        cartIdStmt.setInt(1, userId);
	        rs = cartIdStmt.executeQuery();
	        if (rs.next()) {
	            cartId = rs.getInt("cart_id");
	        }
	        
	        //  If no cart, insert a new one and get generated cart_id
	        if (cartId == 0) {
	            String insertCartSql = "INSERT INTO Cart (user_id) VALUES (?)";
	            insertCartStmt = con.prepareStatement(insertCartSql, PreparedStatement.RETURN_GENERATED_KEYS);
	            insertCartStmt.setInt(1, userId);
	            int affectedRows = insertCartStmt.executeUpdate();
	            
	            if (affectedRows == 0) {
	                throw new SQLException("Creating cart failed, no rows affected.");
	            }
	            
	            generatedKeys = insertCartStmt.getGeneratedKeys();
	            if (generatedKeys.next()) {
	                cartId = generatedKeys.getInt(1);
	            } else {
	                throw new SQLException("Creating cart failed, no ID obtained.");
	            }
	        }
	        
	        // Getting product_id by product_code
	        int productId = 0;
	        String getProductIdSql = "SELECT product_id FROM product WHERE product_code = ?";
	        productIdStmt = con.prepareStatement(getProductIdSql);
	        productIdStmt.setString(1, productCode);
	        rs = productIdStmt.executeQuery();
	        
	        if (rs.next()) {
	            productId = rs.getInt("product_id");
	        } else {
	            throw new SQLException("Invalid product code: " + productCode);
	        }
	        
	        // Checking if product already in cart
	        String checkProductSql = "SELECT quantity FROM Cart_Product WHERE cart_id = ? AND product_id = ?";
	        int existingQuantity = 0;
	        
	        checkStmt = con.prepareStatement(checkProductSql);
	        checkStmt.setInt(1, cartId);
	        checkStmt.setInt(2, productId);
	        rs = checkStmt.executeQuery();
	        
	        if (rs.next()) {
	            // Product already in cart, update quantity
	            existingQuantity = rs.getInt("quantity");
	            String updateSql = "UPDATE Cart_Product SET quantity = ?, size = ? WHERE cart_id = ? AND product_id = ?";
	            updateStmt = con.prepareStatement(updateSql);
	            updateStmt.setInt(1, existingQuantity + quantity);
	            updateStmt.setString(2, size);
	            updateStmt.setInt(3, cartId);
	            updateStmt.setInt(4, productId);
	            updateStmt.executeUpdate();
	        } else {
	            //Inserting product into Cart_Product with quantity and size
	            String insertCartProductSql = "INSERT INTO Cart_Product (cart_id, product_id, quantity, size) VALUES (?, ?, ?, ?)";
	            insertStmt = con.prepareStatement(insertCartProductSql);
	            insertStmt.setInt(1, cartId);
	            insertStmt.setInt(2, productId);
	            insertStmt.setInt(3, quantity);
	            insertStmt.setString(4, size);
	            insertStmt.executeUpdate();
	        }
	        
	        con.commit(); // Commit transaction
	        return true;
	    } catch (SQLException e) {
	        if (con != null) {
	            try {
	                con.rollback(); // Rollback transaction on error
	            } catch (SQLException ex) {
	                ex.printStackTrace();
	            }
	        }
	        e.printStackTrace();
	        throw e;
	    } finally {
	        // Closing all resources
	        try {
	            if (rs != null) rs.close();
	            if (generatedKeys != null) generatedKeys.close();
	            if (cartIdStmt != null) cartIdStmt.close();
	            if (insertCartStmt != null) insertCartStmt.close();
	            if (productIdStmt != null) productIdStmt.close();
	            if (checkStmt != null) checkStmt.close();
	            if (insertStmt != null) insertStmt.close();
	            if (updateStmt != null) updateStmt.close();
	            if (con != null) {
	                con.setAutoCommit(true); // Reset auto-commit
	                con.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	}

	// Method to get cart products for user
	public List<Map<String, Object>> getCartItemsWithDetails(int userId) throws SQLException, ClassNotFoundException {
	    List<Map<String, Object>> cartItemsList = new ArrayList<>();
	    String sql = "SELECT p.product_id, p.product_name, p.product_price, p.image, p.product_code, " +
	                 "cp.quantity, cp.size " +
	                 "FROM product p " +
	                 "JOIN Cart_Product cp ON p.product_id = cp.product_id " +
	                 "JOIN Cart c ON cp.cart_id = c.cart_id " +
	                 "WHERE c.user_id = ?";
	    
	    try (Connection con = DataBaseConnection.getConnection();
	         PreparedStatement statement = con.prepareStatement(sql)) {
	        statement.setInt(1, userId);
	        try (ResultSet resultSet = statement.executeQuery()) {
	            while (resultSet.next()) {
	                Map<String, Object> item = new HashMap<>();
	                item.put("productId", resultSet.getInt("product_id"));
	                item.put("productName", resultSet.getString("product_name"));
	                item.put("productPrice", resultSet.getDouble("product_price"));
	                item.put("image", resultSet.getString("image"));
	                item.put("productCode", resultSet.getString("product_code"));
	                item.put("quantity", resultSet.getInt("quantity"));
	                item.put("size", resultSet.getString("size"));
	                
	                cartItemsList.add(item);
	            }
	        }
	    }
	    return cartItemsList;
	}
// Method to remove from  user cart 
	public boolean removeFromCart(int userId, String productCode) throws SQLException, ClassNotFoundException {
	    Connection con = null;
	    PreparedStatement cartIdStmt = null;
	    PreparedStatement productIdStmt = null;
	    PreparedStatement deleteStmt = null;
	    ResultSet rs = null;
	    
	    try {
	        con = DataBaseConnection.getConnection();
	        con.setAutoCommit(false); // Start transaction
	        
	        //Getting cart_id for user
	        int cartId = 0;
	        String getCartIdSql = "SELECT cart_id FROM Cart WHERE user_id = ?";
	        cartIdStmt = con.prepareStatement(getCartIdSql);
	        cartIdStmt.setInt(1, userId);
	        rs = cartIdStmt.executeQuery();
	        
	        if (rs.next()) {
	            cartId = rs.getInt("cart_id");
	        } else {
	            return false; // Cart not found
	        }
	        
	        //Getting product_id by product_code
	        int productId = 0;
	        String getProductIdSql = "SELECT product_id FROM product WHERE product_code = ?";
	        productIdStmt = con.prepareStatement(getProductIdSql);
	        productIdStmt.setString(1, productCode);
	        rs = productIdStmt.executeQuery();
	        
	        if (rs.next()) {
	            productId = rs.getInt("product_id");
	        } else {
	            return false; // Product not found
	        }
	        
	        // Deleting from Cart_Product
	        String deleteSql = "DELETE FROM Cart_Product WHERE cart_id = ? AND product_id = ?";
	        deleteStmt = con.prepareStatement(deleteSql);
	        deleteStmt.setInt(1, cartId);
	        deleteStmt.setInt(2, productId);
	        int rowsDeleted = deleteStmt.executeUpdate();
	        
	        con.commit();
	        return rowsDeleted > 0;
	        
	    } catch (Exception e) {
	        if (con != null) {
	            try {
	                con.rollback();
	            } catch (SQLException ex) {
	                ex.printStackTrace();
	            }
	        }
	        throw e;
	    } finally {
	        if (rs != null) rs.close();
	        if (cartIdStmt != null) cartIdStmt.close();
	        if (productIdStmt != null) productIdStmt.close();
	        if (deleteStmt != null) deleteStmt.close();
	        if (con != null) {
	            con.setAutoCommit(true);
	            con.close();
	        }
	    }
	}
	// Method to create an order and record in both order and order_product tables
	public boolean createOrder(OrderModel order, String productCode, int quantity, String size) throws SQLException, ClassNotFoundException {
	    Connection con = null;
	    PreparedStatement orderStmt = null;
	    PreparedStatement productStmt = null;
	    PreparedStatement orderProductStmt = null;
	    ResultSet rs = null;
	    ResultSet generatedKeys = null;
	    
	    try {
	        con = DataBaseConnection.getConnection();
	        con.setAutoCommit(false); // Start transaction
	        
	        // Inserting into order table
	        String insertOrderSql = "INSERT INTO `order` (user_id, placement_date, shipping_address, contact_name, " +
	                               "contact_phone, contact_email, payment_method, order_status, category, brand) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	        
	        orderStmt = con.prepareStatement(insertOrderSql, PreparedStatement.RETURN_GENERATED_KEYS);
	        orderStmt.setInt(1, order.getUserId());
	        orderStmt.setDate(2, new java.sql.Date(System.currentTimeMillis())); // Current date
	        orderStmt.setString(3, order.getShippingAddress());
	        orderStmt.setString(4, order.getContactName());
	        orderStmt.setString(5, order.getContactPhone());
	        orderStmt.setString(6, order.getContactEmail());
	        orderStmt.setString(7, order.getPaymentMethod());
	        orderStmt.setString(8, "Pending"); // Default status
	        orderStmt.setString(9, order.getCategory());
	        orderStmt.setString(10, order.getBrand());
	        
	        int affectedRows = orderStmt.executeUpdate();
	        if (affectedRows == 0) {
	            throw new SQLException("Creating order failed, no rows affected.");
	        }
	        
	        // Getting the generated order_id
	        int orderId = 0;
	        generatedKeys = orderStmt.getGeneratedKeys();
	        if (generatedKeys.next()) {
	            orderId = generatedKeys.getInt(1);
	        } else {
	            throw new SQLException("Creating order failed, no ID obtained.");
	        }
	        
	        // Getting product information
	        int productId = 0;
	        double productPrice = 0;
	        
	        String getProductSql = "SELECT product_id, product_price FROM product WHERE product_code = ?";
	        productStmt = con.prepareStatement(getProductSql);
	        productStmt.setString(1, productCode);
	        rs = productStmt.executeQuery();
	        
	        if (rs.next()) {
	            productId = rs.getInt("product_id");
	            productPrice = rs.getDouble("product_price");
	        } else {
	            throw new SQLException("Product not found with code: " + productCode);
	        }
	        
	        // Inserting into order_product table
	        String insertOrderProductSql = "INSERT INTO order_product (order_id, product_id, quantity, price, size) VALUES (?, ?, ?, ?, ?)";
	        orderProductStmt = con.prepareStatement(insertOrderProductSql);
	        orderProductStmt.setInt(1, orderId);
	        orderProductStmt.setInt(2, productId);
	        orderProductStmt.setInt(3, quantity);
	        orderProductStmt.setDouble(4, productPrice); // Price per unit
	        orderProductStmt.setString(5, size);
	        
	        orderProductStmt.executeUpdate();
	        
	        // Updating stock in product table
	        updateProductStock(con, productId, quantity);
	        
	        // If user was purchasing from cart, remove the item from cart
	        removeFromCartAfterOrder(con, order.getUserId(), productId);
	        
	        con.commit(); // Commit transaction
	        return true;
	        
	    } catch (SQLException e) {
	        if (con != null) {
	            try {
	                con.rollback(); // Rollback transaction on error
	            } catch (SQLException ex) {
	                ex.printStackTrace();
	            }
	        }
	        e.printStackTrace();
	        throw e;
	    } finally {
	        // Close all resources
	        try {
	            if (rs != null) rs.close();
	            if (generatedKeys != null) generatedKeys.close();
	            if (orderStmt != null) orderStmt.close();
	            if (productStmt != null) productStmt.close();
	            if (orderProductStmt != null) orderProductStmt.close();
	            if (con != null) {
	                con.setAutoCommit(true); // Reset auto-commit
	                con.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	}

	// method to update product stock after order
	private void updateProductStock(Connection con, int productId, int quantity) throws SQLException {
	    String updateStockSql = "UPDATE product SET stock = stock - ? WHERE product_id = ? AND stock >= ?";
	    try (PreparedStatement statement = con.prepareStatement(updateStockSql)) {
	        statement.setInt(1, quantity);
	        statement.setInt(2, productId);
	        statement.setInt(3, quantity); // Ensure we have enough stock
	        
	        int rowsUpdated = statement.executeUpdate();
	        if (rowsUpdated == 0) {
	            throw new SQLException("Unable to update stock for product ID: " + productId + ". Insufficient stock.");
	        }
	    }
	}

	//method to remove item from cart after successful order
	private void removeFromCartAfterOrder(Connection con, int userId, int productId) throws SQLException {
	    // First get the cart_id
	    String getCartIdSql = "SELECT cart_id FROM Cart WHERE user_id = ?";
	    try (PreparedStatement statement = con.prepareStatement(getCartIdSql)) {
	        statement.setInt(1, userId);
	        try (ResultSet rs = statement.executeQuery()) {
	            if (rs.next()) {
	                int cartId = rs.getInt("cart_id");
	                
	                // Remove the item from Cart_Product
	                String removeItemSql = "DELETE FROM Cart_Product WHERE cart_id = ? AND product_id = ?";
	                try (PreparedStatement removeStmt = con.prepareStatement(removeItemSql)) {
	                    removeStmt.setInt(1, cartId);
	                    removeStmt.setInt(2, productId);
	                    removeStmt.executeUpdate();
	                }
	            }
	        }
	    }
	}
	// Method to update order status (for admin)
	public boolean updateOrderStatus(int orderId, String status) throws SQLException, ClassNotFoundException {
	    String sql = "UPDATE `order` SET status = ? WHERE order_id = ?";
	    
	    try (Connection con = DataBaseConnection.getConnection();
	         PreparedStatement statement = con.prepareStatement(sql)) {
	        statement.setString(1, status);
	        statement.setInt(2, orderId);
	        
	        int rowsUpdated = statement.executeUpdate();
	        return rowsUpdated > 0;
	    }
	}
	// Method to get total products sold
	public int getTotalProductsSold() throws SQLException, ClassNotFoundException {
	    int total = 0;
	    String sql = "SELECT SUM(op.quantity) as total_sold " +
	                 "FROM order_product op " +
	                 "JOIN `order` o ON op.order_id = o.order_id";
	    
	    try (Connection con = DataBaseConnection.getConnection();
	         PreparedStatement stmt = con.prepareStatement(sql);
	         ResultSet rs = stmt.executeQuery()) {
	        
	        if (rs.next()) {
	            total = rs.getInt("total_sold");
	        }
	    }
	    return total;
	}

	// Method to get top brand by sales
	public String getTopBrand() throws SQLException, ClassNotFoundException {
	    Map<String, Integer> brandCounts = new HashMap<>();
	    String topBrand = "N/A";
	    int maxCount = 0;
	    
	    // SQL query to count orders by brand
	    String sql = "SELECT o.brand, SUM(op.quantity) as count " +
	                 "FROM `order` o " +
	                 "JOIN order_product op ON o.order_id = op.order_id " +
	                 "WHERE o.brand IS NOT NULL AND o.brand != '' " +
	                 "GROUP BY o.brand " +
	                 "ORDER BY count DESC";
	    
	    try (Connection con = DataBaseConnection.getConnection();
	         PreparedStatement stmt = con.prepareStatement(sql);
	         ResultSet rs = stmt.executeQuery()) {
	        
	        // Finding the brand with most orders
	        while (rs.next()) {
	            String brand = rs.getString("brand");
	            int count = rs.getInt("count");
	            
	            // Skipping null brands
	            if (brand == null || brand.equals("NULL") || brand.trim().isEmpty()) {
	                continue;
	            }
	            
	            if (count > maxCount) {
	                maxCount = count;
	                topBrand = brand;
	            }
	        }
	    }
	    
	    // If no valid brands found or all were NULL this runs
	    if ("N/A".equals(topBrand)) {
	        // Check specific brands in the specified list
	        String specificBrands = "Nike,Caliber,Puma,Adidas,New Balance,Goldstar,Converse,Vans";
	        String[] brands = specificBrands.split(",");
	        
	        for (String brand : brands) {
	            int count = countBrandOrders(brand.trim());
	            if (count > maxCount) {
	                maxCount = count;
	                topBrand = brand.trim();
	            }
	        }
	    }
	    
	    return topBrand;
	}

	// Method to count orders by brand
	private int countBrandOrders(String brand) throws SQLException, ClassNotFoundException {
	    int count = 0;
	    String sql = "SELECT SUM(op.quantity) as count " +
	                 "FROM `order` o " +
	                 "JOIN order_product op ON o.order_id = op.order_id " +
	                 "WHERE o.brand = ?";
	    
	    try (Connection con = DataBaseConnection.getConnection();
	         PreparedStatement stmt = con.prepareStatement(sql)) {
	        
	        stmt.setString(1, brand);
	        try (ResultSet rs = stmt.executeQuery()) {
	            if (rs.next()) {
	                count = rs.getInt("count");
	            }
	        }
	    }
	    return count;
	}

	// Method to get top category by sales
	public String getTopCategory() throws SQLException, ClassNotFoundException {
	    Map<String, Integer> categoryCounts = new HashMap<>();
	    String topCategory = "N/A";
	    int maxCount = 0;
	    
	    // SQL query to count orders by category
	    String sql = "SELECT o.category, SUM(op.quantity) as count " +
	                 "FROM `order` o " +
	                 "JOIN order_product op ON o.order_id = op.order_id " +
	                 "WHERE o.category IS NOT NULL AND o.category != '' " +
	                 "GROUP BY o.category " +
	                 "ORDER BY count DESC";
	    
	    try (Connection con = DataBaseConnection.getConnection();
	         PreparedStatement stmt = con.prepareStatement(sql);
	         ResultSet rs = stmt.executeQuery()) {
	        
	        // Finding the category with most orders
	        while (rs.next()) {
	            String category = rs.getString("category");
	            int count = rs.getInt("count");
	            
	            // Skipping null categories
	            if (category == null || category.equals("NULL") || category.trim().isEmpty()) {
	                continue;
	            }
	            
	            if (count > maxCount) {
	                maxCount = count;
	                topCategory = category;
	            }
	        }
	    }
	    
	    // If no valid categories found or all were NULL
	    if ("N/A".equals(topCategory)) {
	        // Checking specific categories in the specified list
	        String specificCategories = "Mens,Womens,Kids";
	        String[] categories = specificCategories.split(",");
	        
	        for (String category : categories) {
	            int count = countCategoryOrders(category.trim());
	            if (count > maxCount) {
	                maxCount = count;
	                topCategory = category.trim();
	            }
	        }
	    }
	    
	    return topCategory;
	}

	// Method to count orders by category
	private int countCategoryOrders(String category) throws SQLException, ClassNotFoundException {
	    int count = 0;
	    String sql = "SELECT SUM(op.quantity) as count " +
	                 "FROM `order` o " +
	                 "JOIN order_product op ON o.order_id = op.order_id " +
	                 "WHERE o.category = ?";
	    
	    try (Connection con = DataBaseConnection.getConnection();
	         PreparedStatement stmt = con.prepareStatement(sql)) {
	        
	        stmt.setString(1, category);
	        try (ResultSet rs = stmt.executeQuery()) {
	            if (rs.next()) {
	                count = rs.getInt("count");
	            }
	        }
	    }
	    return count;
	}

// Method to get sales report
    public List<Map<String, Object>> getSalesReport() throws SQLException, ClassNotFoundException {
        List<Map<String, Object>> salesData = new ArrayList<>();
        
        String sql = "SELECT o.order_id, o.placement_date, op.quantity, op.price, p.product_name, " +
                     "p.brand_name, o.category, o.order_status " +
                     "FROM `order` o " +
                     "JOIN order_product op ON o.order_id = op.order_id " +
                     "JOIN product p ON op.product_id = p.product_id " +
                     "ORDER BY o.placement_date DESC";
        
        try (Connection con = DataBaseConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Map<String, Object> orderData = new HashMap<>();
                orderData.put("orderId", rs.getInt("order_id"));
                orderData.put("placementDate", rs.getDate("placement_date"));
                orderData.put("quantity", rs.getInt("quantity"));
                orderData.put("price", rs.getDouble("price"));
                orderData.put("totalPrice", rs.getInt("quantity") * rs.getDouble("price"));
                orderData.put("productName", rs.getString("product_name"));
                orderData.put("brandName", rs.getString("brand_name"));
                orderData.put("category", rs.getString("category"));
                orderData.put("orderStatus", rs.getString("order_status"));
                
                salesData.add(orderData);
            }
        }
        
        return salesData;
    }
// Method to get sale by brand
    public Map<String, Integer> getBrandSales() throws SQLException, ClassNotFoundException {
        Map<String, Integer> brandSales = new HashMap<>();
        
        String sql = "SELECT p.brand_name, SUM(op.quantity) as total_sold " +
                     "FROM order_product op " +
                     "JOIN product p ON op.product_id = p.product_id " +
                     "GROUP BY p.brand_name " +
                     "ORDER BY total_sold DESC";
        
        try (Connection con = DataBaseConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                String brandName = rs.getString("brand_name");
                int totalSold = rs.getInt("total_sold");
                
                if (brandName != null && !brandName.trim().isEmpty()) {
                    brandSales.put(brandName, totalSold);
                }
            }
        }
        
        return brandSales;
    }
 // Method to get sale by Category
    public Map<String, Integer> getCategorySales() throws SQLException, ClassNotFoundException {
        Map<String, Integer> categorySales = new HashMap<>();
        
        String sql = "SELECT o.category, SUM(op.quantity) as total_sold " +
                     "FROM `order` o " +
                     "JOIN order_product op ON o.order_id = op.order_id " +
                     "WHERE o.category IS NOT NULL AND o.category != '' " +
                     "GROUP BY o.category " +
                     "ORDER BY total_sold DESC";
        
        try (Connection con = DataBaseConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                String category = rs.getString("category");
                int totalSold = rs.getInt("total_sold");
                
                if (category != null && !category.trim().isEmpty() && !category.equals("NULL")) {
                    categorySales.put(category, totalSold);
                }
            }
        }
        
        // Making sure we have entries for the specified categories
        String[] specificCategories = {"Mens", "Womens", "Kids"};
        for (String category : specificCategories) {
            if (!categorySales.containsKey(category)) {
                categorySales.put(category, 0);
            }
        }
        
        return categorySales;
    }
 // Method to get user's order history (for User panel)
    public List<Map<String, Object>> getUserOrderHistory(int userId, int limit) throws SQLException, ClassNotFoundException {
        List<Map<String, Object>> orderList = new ArrayList<>();
        
        String sql = "SELECT o.order_id, o.placement_date, " +
                     "SUM(op.quantity * op.price) as total_amount, " +
                     "o.order_status " +
                     "FROM `order` o " +
                     "JOIN order_product op ON o.order_id = op.order_id " +
                     "WHERE o.user_id = ? " +
                     "GROUP BY o.order_id " +
                     "ORDER BY o.placement_date DESC";
        
        if (limit > 0) {
            sql += " LIMIT ?";
        }
        
        try (Connection con = DataBaseConnection.getConnection();
             PreparedStatement statement = con.prepareStatement(sql)) {
            
            statement.setInt(1, userId);
            if (limit > 0) {
                statement.setInt(2, limit);
            }
            
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Map<String, Object> order = new HashMap<>();
                    order.put("orderId", resultSet.getInt("order_id"));
                    order.put("orderDate", resultSet.getDate("placement_date"));
                    order.put("totalAmount", resultSet.getDouble("total_amount"));
                    order.put("status", resultSet.getString("order_status"));
                    
                    orderList.add(order);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        
        return orderList;
    }

    // Method to get order details including products for a specific order
    public Map<String, Object> getOrderDetails(int orderId) throws SQLException, ClassNotFoundException {
        Map<String, Object> orderDetails = new HashMap<>();
        List<Map<String, Object>> orderItems = new ArrayList<>();
        
        // Getting order header information
        String orderSql = "SELECT o.order_id, o.placement_date, o.shipping_address, " +
                          "o.contact_name, o.contact_phone, o.contact_email, " +
                          "o.payment_method, o.order_status " +
                          "FROM `order` o WHERE o.order_id = ?";
        
        // Getting order line items
        String itemsSql = "SELECT p.product_name, p.image, op.quantity, op.price, op.size " +
                          "FROM order_product op " +
                          "JOIN product p ON op.product_id = p.product_id " +
                          "WHERE op.order_id = ?";
        
        try (Connection con = DataBaseConnection.getConnection();
             PreparedStatement orderStmt = con.prepareStatement(orderSql);
             PreparedStatement itemsStmt = con.prepareStatement(itemsSql)) {
            
            // Getting order header
            orderStmt.setInt(1, orderId);
            try (ResultSet rs = orderStmt.executeQuery()) {
                if (rs.next()) {
                    orderDetails.put("orderId", rs.getInt("order_id"));
                    orderDetails.put("orderDate", rs.getDate("placement_date"));
                    orderDetails.put("shippingAddress", rs.getString("shipping_address"));
                    orderDetails.put("contactName", rs.getString("contact_name"));
                    orderDetails.put("contactPhone", rs.getString("contact_phone"));
                    orderDetails.put("contactEmail", rs.getString("contact_email"));
                    orderDetails.put("paymentMethod", rs.getString("payment_method"));
                    orderDetails.put("status", rs.getString("order_status"));
                }
            }
            
            // Getting order items
            itemsStmt.setInt(1, orderId);
            try (ResultSet rs = itemsStmt.executeQuery()) {
                double totalAmount = 0.0;
                
                while (rs.next()) {
                    Map<String, Object> item = new HashMap<>();
                    item.put("productName", rs.getString("product_name"));
                    item.put("image", rs.getString("image"));
                    item.put("quantity", rs.getInt("quantity"));
                    item.put("price", rs.getDouble("price"));
                    item.put("size", rs.getString("size"));
                    
                    double itemTotal = rs.getInt("quantity") * rs.getDouble("price");
                    item.put("itemTotal", itemTotal);
                    totalAmount += itemTotal;
                    
                    orderItems.add(item);
                }
                
                orderDetails.put("totalAmount", totalAmount);
                orderDetails.put("items", orderItems);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        
        return orderDetails;
    }
    
    // Method to gell all cart iteams of a user
    public Map<String, Integer> getTotalCartItems(int userId) throws SQLException, ClassNotFoundException {
        Map<String, Integer> cartCounts = new HashMap<>();
        int uniqueProducts = 0;

        String sql = "SELECT SUM(cp.quantity) as total_items, COUNT(DISTINCT cp.product_id) as unique_products " +
                     "FROM Cart c " +
                     "JOIN Cart_Product cp ON c.cart_id = cp.cart_id " +
                     "WHERE c.user_id = ?";

        try (Connection con = DataBaseConnection.getConnection();
             PreparedStatement statement = con.prepareStatement(sql)) {
            statement.setInt(1, userId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
           
                    uniqueProducts = resultSet.getInt("unique_products");
                }
            }
        }

    
        cartCounts.put("uniqueProducts", uniqueProducts);
        return cartCounts;
    }
    // Method to get order details that the user had ordered
    public List<SalesDetailModel> getSalesDetails() {
        List<SalesDetailModel> salesDetails = new ArrayList<>();
        String query = "SELECT DISTINCT " +
            "o.order_id, " +
            "o.contact_name, " +
            "o.shipping_address, " +
            "o.contact_email, " +
            "o.contact_phone, " +
            "o.Order_status, " +
            "GROUP_CONCAT(DISTINCT p.product_name SEPARATOR ', ') AS product_names, " +
            "GROUP_CONCAT(DISTINCT p.product_code SEPARATOR ', ') AS product_codes " +
            "FROM `order` o " +
            "JOIN order_product op ON o.order_id = op.order_id " +
            "JOIN product p ON op.product_id = p.product_id " +
            "GROUP BY o.order_id, o.contact_name, o.shipping_address, " +
            "o.contact_email, o.contact_phone, o.Order_status";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                SalesDetailModel detail = new SalesDetailModel();
                detail.setOrderId(rs.getInt("order_id"));
                detail.setContactName(rs.getString("contact_name"));
                detail.setShippingAddress(rs.getString("shipping_address"));
                detail.setContactEmail(rs.getString("contact_email"));
                detail.setContactPhone(rs.getString("contact_phone"));
                detail.setOrderStatus(rs.getString("Order_status"));
                
                // Concatenate product names and codes if multiple products
                detail.setProductName(rs.getString("product_names"));
                detail.setProductCode(rs.getString("product_codes"));

                salesDetails.add(detail);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return salesDetails;
    }
    
    // Method to update order status
    public boolean updateSalesStatus(int orderId, String newStatus) {
        String query = "UPDATE `order` SET Order_status = ? WHERE order_id = ?";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            // Debugging print statements
            System.out.println("Updating Order ID: " + orderId);
            System.out.println("New Status: " + newStatus);

            pstmt.setString(1, newStatus);
            pstmt.setInt(2, orderId);

            int rowsAffected = pstmt.executeUpdate();
            
            // Debugging print statement
            System.out.println("Rows Affected: " + rowsAffected);

            return rowsAffected > 0;
        } catch (SQLException | ClassNotFoundException e) {
            // More detailed error logging
            System.err.println("Error updating order status:");
            e.printStackTrace();
            return false;
        }
    }

	// Utility method to get submitted file name from Part header
	private String getFileName(Part part) {
		String contentDisp = part.getHeader("content-disposition");
		String[] tokens = contentDisp.split(";");
		for (String token : tokens) {
			token = token.trim();
			if (token.startsWith("filename")) {
				String fileName = token.substring(token.indexOf('=') + 1).trim().replace("\"", "");
				fileName = fileName.substring(Math.max(fileName.lastIndexOf('/'), fileName.lastIndexOf('\\')) + 1);
				return fileName;
			}
		}
		return "";
	}
}